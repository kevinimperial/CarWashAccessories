package com.example.carwashaccessories;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Accessories extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_accessories);
    }
}